//Uow No: W1990085
//IIT No: 20222360
//Name: N.P.Muthumala

import java.io.*;
import java.util.*;

public class TaskOne {
    public static int pizza_Count = 100;//From this integer value variable shows how many pizza stock in this relevant program.
    public static String[] customer_Queue = {"","","","","","","","","",""};// Array to store customer names

    public static String[] cashier_One = {"X", "X","","",""};// In this cashier_one array shows first Queue with 2 slots
    public static String[] cashier_Two = {"X", "X", "X","",""};// In this cashier_Two array shows Second Queue with 3 slots
    public static String[] cashier_Three = {"X", "X", "X", "X", "X"};// In this cashier_Three array shows Third Queue with 5 slots



    /**
     * The following displayMenu method is used to display the menu console to the user, from this console. He or she
     * can choose following options by their choices
     */
    public static void menuConsole() {
        //From this method will display menu console

        System.out.println("100 or VFQ: View all Queues.");
        System.out.println("101 or VEQ: View all Empty Queues.");
        System.out.println("102 or ACQ: Add customer to a Queue.");
        System.out.println("103 or RCQ: Remove a customer from a Queue. (From a specific location)");
        System.out.println("104 or PCQ: Remove a served customer.");
        System.out.println("105 or VCS: View Customers Sorted in alphabetical order.");
        System.out.println("106 or SPD: Store Program Data into file.");
        System.out.println("107 or LPD: Load Program Data from file.");
        System.out.println("108 or STK: View Remaining Pizza Stock.");
        System.out.println("109 or AFS: Add Pizzas to Stock.");
        System.out.println("999 or EXT: Exit the Program.");
        System.out.print("Choice: ");

    }


    /**
     * The following viewCashierQueues Method is using when user entering 100 or VFQ option through menu console,
     * so it will print all cashier queues to the user
     */
    public static void viewCashierQueues() {
        System.out.println("\n************************************");
        System.out.println("*     Viewing CASHIER QUEUES       *");
        System.out.println("************************************");
        System.out.println(" " + cashier_One[0] + "\t" + cashier_Two[0] + "\t" + cashier_Three[0]);
        System.out.println(" " + cashier_One[1] + "\t" + cashier_Two[1] + "\t" + cashier_Three[1]);
        System.out.println(" " + " " + "\t" + cashier_Two[2] + "\t" + cashier_Three[2]);
        System.out.println(" " + " " + "\t" + " " + "\t" + cashier_Three[3]);
        System.out.println(" " + " " + "\t" + " " + "\t" + cashier_Three[4]);
    }


    // The following main method is to control all other methods by using switch case function
    public static void main(String[] args) {

        Scanner user_giving_option = new Scanner(System.in);
        boolean exit = false;
        while (!exit){
            menuConsole();
            String choice= user_giving_option.nextLine();
            switch(choice){
                case"100":
                case"VFQ":
                    viewCashierQueues();
                    break;
                case"101":
                case"VEQ":
                    viewAllCashierEmptyQueues();
                    break;
                case"102":
                case"ACQ":
                    addCustomerToQueue();

                    break;
                case"103":
                case"RCQ":
                    removeACustomer();
                    break;
                case"104":
                case"PCQ":
                    removeAServedCustomer();
                    break;
                case"105":
                case"VCS":
                    reOrganizedCustomers();
                    break;
                case"106":
                case"SPD":
                    storeDataToFile();
                    break;
                case"107":
                case"LPD":
                    loadData();
                    break;
                case"108":
                case"STK":
                    pizzaCount();
                    break;
                case"109":
                case"AFS":
                    addPizzaStock();
                    break;
                case"999":
                case"EXT":
                    exit = true;
                    break;

                default:
                    System.out.println("Invalid Input");

            }
        }
    }

    /**
     * This following viewAllEmptyQueues method is used to display all the empty Queues
     */

    public static void viewAllCashierEmptyQueues(){
        System.out.println("\n********************************");
        System.out.println("*     !All Queues are EMPTY!     *");
        System.out.println("*         !NO CUSTOMERS!         *");
        System.out.println("**********************************");

        //checking the all empty queues using and if else statements

        if (cashier_One[0].equals("X") && cashier_One[1].equals("X")) {
            System.out.println("Cashier One is empty(There is no customers in this queue)");
        }

        if (cashier_Two[0].equals("X") && cashier_Two[1].equals("X") && cashier_Two[2].equals("X")) {
            System.out.println("Cashier Two is empty(There is no customers in this queue)");
        }

        if (cashier_Three[0].equals("X") && cashier_Three[1].equals("X") && cashier_Three[2].equals("X")
                && cashier_Three[3].equals("X") && cashier_Three[4].equals("X")) {
            System.out.println("Cashier Three is empty(There is no customers in this queue)");
        }

    }

    /**
     * The following addCustomerToQueue method is used to add customers to the queue,and it adds customers to the first empty slot.

     */
    public static void addCustomerToQueue(){
        Scanner customerInfo = new Scanner(System.in);
        try {

            System.out.print("Enter the customer name: ");
            String customerCredentials = customerInfo.nextLine();

            //replacing 'X' with 'o' and adding customers name in to customerQueue array.

            for (int x = 0; x < 5; x++) {
                if (cashier_One[x].equals("X")) {
                    cashier_One[x] = "O";
                    customer_Queue[x] = customerCredentials;
                    break;

                } else if (cashier_Two[x].equals("X")) {
                    cashier_Two[x] = "O";
                    customer_Queue[x + 2] = customerCredentials;
                    break;

                } else if (cashier_Three[x].equals("X")) {
                    cashier_Three[x] = "O";
                    customer_Queue[x + 5] = customerCredentials;
                    break;


                }
            }

        }catch (InputMismatchException e){
            System.out.println("__Enter a reasonable valid Input__");}

    }


    /**
     * The following recognizeOrganizedCustomers method is used to sort out the customer names in Alphabetic Order.
     */

    public static void reOrganizedCustomers(){
        String[] alphabeticQueue = Arrays.copyOf(customer_Queue, customer_Queue.length);

        //Bubble sort method used to sort customerQueue array


        for (int i = 0; i < alphabeticQueue.length - 1; i++) {
            for (int j = 0; j < alphabeticQueue.length - i - 1; j++) {
                if (alphabeticQueue[j].compareTo(alphabeticQueue[j + 1]) > 0) {
                    String temp = alphabeticQueue[j];
                    alphabeticQueue[j] = alphabeticQueue[j + 1];
                    alphabeticQueue[j + 1] = temp;
                }
            }
        }
        //printing sorted customer names

        System.out.println("Displaying Alphabetically Sorted Customer Queue:");
        for (String customer : alphabeticQueue) {
            if (!customer.isEmpty()) {
                System.out.println(customer);
            }
        }



    }

    /**
     * The Following removeACustomer is used to remove a customer when the user enter from a specific queue and a position.
     */

    public static void removeACustomer(){

        //Asking user to enter customers position and queue number

        String[] selectedCustomerQueue =null;
        Scanner removeCus= new Scanner(System.in);
        System.out.print("Please select a cashier queue (1,2 or 3) :  ");
        int customerQueueNumber= removeCus.nextInt();

        if (customerQueueNumber<1 ||customerQueueNumber>3){
            System.out.println("Invalid cashier Queue Number!!");
        }
        switch (customerQueueNumber){
            case 1:
                selectedCustomerQueue= cashier_One;
                break;
            case 2:
                selectedCustomerQueue= cashier_Two;
                break;
            case 3:
                selectedCustomerQueue= cashier_Three;
                break;
        }
        Scanner remove = new Scanner(System.in);
        System.out.print("Enter a selected cashier queue position : ");
        int customerPosition=remove.nextInt();

        if(customerPosition<1||customerPosition>selectedCustomerQueue.length){
            System.out.println("Invalid customer Position!!");
            return;
        }
        if (selectedCustomerQueue[customerPosition-1].equals("X")) {
            System.out.println("No customer found at this position!!");
            return;
        }
        String removedCustomer=selectedCustomerQueue[customerPosition-1];
        selectedCustomerQueue[customerPosition-1]="X";

        // replacing line
        if (selectedCustomerQueue == cashier_One) {
            for (int i=customerPosition; i<2; i++) {
                if  (i==1) {
                    cashier_One[i] = "X";
                }
                else {
                    cashier_One[customerPosition] = cashier_One[customerPosition-1];
                }
            }
        }
        else if (selectedCustomerQueue == cashier_Two) {
            for (int i=customerPosition; i<3; i++) {
                if  (i==2) {
                    cashier_Two[i] = "X";
                }
                else {
                    cashier_Two[customerPosition] = cashier_Two[customerPosition-1];
                }
            }
        }
        else if (selectedCustomerQueue == cashier_Three) {
            for (int i=customerPosition; i<5; i++) {
                if  (i==4) {
                    cashier_Three[i] = "X";
                }
                else {
                    cashier_Three[customerPosition] = cashier_Three[customerPosition-1];
                }
            }
        }

        System.out.println("Customer removed from the given queue "+customerQueueNumber+" .");


    }




    /**
     * The following removeAServedCustomer method is used to remove a served customer queue and replacing the served customer.

     */


    public static void removeAServedCustomer() {

        Scanner pizza = new Scanner(System.in);
        System.out.print("Enter a cashier queue number to remove the served customer: ");
        int servedQueue= pizza.nextInt();

        //getting queue number.

        if(servedQueue<1||servedQueue>3){
            System.out.println("Invalid Cashier Queue Number!!");
            return;
        }

        //switch case used to remove customer and replace a served customer to the queue.

        switch (servedQueue) {
            case 1:
                if (cashier_One[0].equals("X")) {
                    System.out.println("There is no customer on the selected queue");
                }
                else {
                    cashier_One[0] = "X";
                    for (int i=0; i<2; i++) {
                        if (i==1) {
                            cashier_One[i] = "X";
                        }
                        else {
                            cashier_One[i] = cashier_One[i + 1];
                        }

                    }
                    customer_Queue[0]="";

                }

                break;
            case 2:
                if (cashier_Two[0].equals("X")) {
                    System.out.println("There is no customer on the selected queue");
                }
                else {
                    cashier_Two[0] = "X";
                    for (int y=0; y<3; y++) {
                        if (y==2) {
                            cashier_Two[y] = "X";
                        }
                        else {
                            cashier_Two[y] = cashier_Two[y + 1];
                        }

                    }
                    customer_Queue[1]="";
                }
                break;

            case 3:
                if (cashier_Three[0].equals("X")) {
                    System.out.println("There is no customer on the selected queue");
                }
                else {
                    cashier_Three[0] = "X";
                    for (int z=0; z<5; z++) {
                        if (z==4) {
                            cashier_Three[z] = "X";
                        }
                        else {
                            cashier_Three[z] = cashier_Three[z + 1];
                        }

                    }
                    customer_Queue[2]="";
                }
                break;
            default:
                System.out.println("Invalid Queue Number");
                return;
        }



        // reducing the Pizza stock

        pizza_Count -=5;

        System.out.println("Served customer removed from queue " + servedQueue);
        System.out.println("Pizza count reduced by 5. Remaining pizzas: " + pizza_Count);
        viewCashierQueues();



    }


    /**
     * The following AddPizzaStock method is used to add pizzas to the stock
     */

    public static void addPizzaStock(){
        try {
            Scanner newPizza = new Scanner(System.in);
            System.out.print("Enter the number of PIZZAS need to add: ");
            int addedPizzas = newPizza.nextInt();

            //adding Pizzas only if it is less than 50
            if (pizza_Count < 100 && (addedPizzas + pizza_Count) <= 100) {
                pizza_Count += addedPizzas;
                System.out.println();
                System.out.println(addedPizzas + " PIZZAS added to stock");
            } else {
                System.out.println();
                System.out.println("You cannot add " + addedPizzas + " PIZZAS to stock.");
                System.out.println("Maximum PIZZA stock is 100.");
            }

        } catch (Exception e) {
            System.out.println("Invalid pizza count input. Please enter a valid integer value.");
        }

    }

    /**
     * PizzaCount is used to display the remaining Pizza stock
     */

    public static void pizzaCount(){
        System.out.println("Remaining Pizza Stock is "+ pizza_Count);
    }

    /**
     * The following storeDataToFile method is used to store customer data and pizza stock in a text file.
     */


    public static void storeDataToFile() {
        try {
            FileWriter fileWriter = new FileWriter("Storing_Info.txt");

            fileWriter.write("Customers in Cashier 1 queue:\n");
            for (int count = 0; count < customer_Queue.length && count < 2; count++) {
                String customer = customer_Queue[count];
                if (!customer.isEmpty()) {
                    fileWriter.write("1 - " + customer + "\n");
                }
            }

            fileWriter.write("\nCustomers in Cashier 2 queue:\n");
            for (int count = 2; count < customer_Queue.length && count < 5; count++) {
                String customer = customer_Queue[count];
                if (!customer.isEmpty()) {
                    fileWriter.write("2 - " + customer + "\n");
                }
            }

            fileWriter.write("\nCustomers in Cashier 3 queue:\n");
            for (int count = 5; count < customer_Queue.length && count < 10; count++) {
                String customer = customer_Queue[count];
                if (!customer.isEmpty()) {
                    fileWriter.write("3 - " + customer + "\n");
                }
            }

            fileWriter.write("\nRemaining pizza stock: " + pizza_Count);

            fileWriter.close();
            System.out.println("All the data was successfully stored into a file(file Name : 'Storing_Info.txt'");
        } catch (IOException e) {
            System.out.println("An error occurred while storing the data.");
        }
    }

    /**
     * The following loadData method is used to loadData in the customer data file.
     */

    public static void loadData() {
        try {
            for (int i = 0; i< customer_Queue.length; i++) {
                customer_Queue[i] = "";
            }
            for (int i = 0; i< cashier_One.length; i++) {
                if (cashier_One[i].equals("X") || cashier_One[i].equals("O")) {
                    cashier_One[i] = "X";
                }
            }
            for (int i = 0; i< cashier_Two.length; i++) {
                if (cashier_Two[i].equals("X") || cashier_Two[i].equals("O")) {
                    cashier_Two[i] = "X";
                }
            }
            for (int i = 0; i< cashier_Three.length; i++) {
                if (cashier_Three[i].equals("X") || cashier_Three[i].equals("O")) {
                    cashier_Three[i] = "X";
                }
            }
            File file = new File("Data.txt");
            Scanner user = new Scanner(file);

            while (user.hasNextLine()) {
                String path = user.nextLine();
                path = path.trim();
                String[] data = path.split(" ");

                if (data.length == 3) {
                    int queuePosition = Integer.parseInt(data[0]) - 1;
                    String name = data[2];

                    for (int i = 0; i < 5; i++) {
                        if (queuePosition == 0 && cashier_One[i].equals("X")) {
                            cashier_One[i] = "O";
                            customer_Queue[i] = name;

                        } else if (queuePosition == 1 && cashier_Two[i].equals("X")) {
                            cashier_Two[i] = "O";
                            customer_Queue[i + 2] = name;
                            break;
                        } else if (queuePosition == 2 && cashier_Three[i].equals("X")) {
                            cashier_Three[i] = "O";
                            customer_Queue[i + 5] = name;
                            break;
                        }
                    }
                }
            }

            user.close();
            System.out.println("All sensitive data was successfully loaded from the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while loading the data.");
        }
    }
}