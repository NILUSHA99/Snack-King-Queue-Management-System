import java.util.*;
import java.io.*;

public class Main {
    // Define the following variables and arrays Cashier queues
    private static WaitingCustomerQueue customerWaitingList = new WaitingCustomerQueue(10);

    //Define a integer type array called cashierQueuesIncome
    public static int[] cashierQueuesIncome;

    //Define a integer type variable called pizza_Count, and it is equal to 100
    private static int pizza_Count = 100;

    //The following arrays are the main arrays in this program
    //All arrays are in string type
    public static String[] Cashier_One = {"X", "X"};
    public static String[] Cashier_Two = {"X", "X", "X"};
    public static String[] Cashier_Three = {"X", "X", "X", "X", "X"};


    private static CustomerSnackQueue[] currentQueue = new CustomerSnackQueue[3];


    // The following menuConsole method is to Display the menu console to choose options by user
    private static void menuConsole() {

        System.out.println("100 or VFQ: View all Queues.");
        System.out.println("101 or VEQ: View all Empty Queues.");
        System.out.println("102 or ACQ: Add customer to a Queue.");
        System.out.println("103 or RCQ: Remove a customer from a Queue. (From a specific location)");
        System.out.println("104 or PCQ: Remove a served customer.");
        System.out.println("105 or VCS: View Customers Sorted in alphabetical order.");
        System.out.println("106 or SPD: Store Program Data into file.");
        System.out.println("107 or LPD: Load Program Data from file.");
        System.out.println("108 or STK: View Remaining Pizza Stock.");
        System.out.println("109 or AFS: Add Pizzas to Stock.");
        System.out.println("110 or IFQ: Cashier Queue Income");
        System.out.println("999 or EXT: Exit the Program.");
        System.out.print("Enter an option: ");
    }



    // The following main method is to control all other methods by using switch case function
    public static void main(String[] args) {
        Scanner Enter = new Scanner(System.in);

        // Define the cashier ques and creating a new variable called cashierQueuesIncome

        currentQueue[0] = new CustomerSnackQueue(2);
        currentQueue[1] = new CustomerSnackQueue(3);
        currentQueue[2] = new CustomerSnackQueue(5);
        cashierQueuesIncome = new int[currentQueue.length];


        while (true) {
            menuConsole();
            String choice = Enter.nextLine();
            switch (choice) {
                case "100":
                case "VFQ":
                    viewCashierQueues();
                    break;
                case "101":
                case "VEQ":
                    viewAllCashierEmptyQueues();
                    break;
                case "102":
                case "ACQ":
                    addCustomerToCashierQueue();


                    break;
                case "103":
                case "RCQ":
                    removeCustomerFromCashierQueue();

                    break;
                case "104":
                case "PCQ":
                    removeAServedCustomer();


                    break;
                case "105":
                case "VCS":
                    reOrganizedCustomers();

                    break;
                case "106":
                case "SPD":
                    storeDatatoTextFile();

                    break;
                case "107":
                case "LPD":
                    loadDatatoTextFile();

                    break;
                case "108":
                case "STK":
                    pizzaStock();


                    break;
                case "109":
                case "AFS":
                    addPizzaStock();
                    break;

                case "110":
                case "IFQ":
                    cashierQueuesIncome();
                    break;

                case "999":
                case "EXT":
                    System.exit(0);
                    break;

                default:
                    System.out.println("You Given an Invalid Input!!!!");
            }
        }
    }



    // The following method is to use to View all the cashier queues
    private static void viewCashierQueues() {

        System.out.println("\n************************************");
        System.out.println("*     Viewing CASHIER QUEUES       *");
        System.out.println("************************************");
        System.out.println(" " + Cashier_One[0] + "\t" + Cashier_Two[0] + "\t" + Cashier_Three[0]);
        System.out.println(" " + Cashier_One[1] + "\t" + Cashier_Two[1] + "\t" + Cashier_Three[1]);
        System.out.println(" " + " " + "\t" + Cashier_Two[2] + "\t" + Cashier_Three[2]);
        System.out.println(" " + " " + "\t" + " " + "\t" + Cashier_Three[3]);
        System.out.println(" " + " " + "\t" + " " + "\t" + Cashier_Three[4]);

    }



    // The following method is to use to View empty cashier queues
    private static void viewAllCashierEmptyQueues() {
        System.out.println("\n********************************");
        System.out.println("*     !These Queues are EMPTY!     *");
        System.out.println("*         !NO CUSTOMERS!         *");
        System.out.println("**********************************");

        // Checking the empty cashier queues using if statement by 'X' condition

        if (Cashier_One[0].equals("X") && Cashier_One[1].equals("X")) {
            System.out.println("Cashier One is empty(There is no customers in this queue)");
        }

        if (Cashier_Two[0].equals("X") && Cashier_Two[1].equals("X") && Cashier_Two[2].equals("X")) {
            System.out.println("Cashier Two is empty(There is no customers in this queue)");
        }

        if (Cashier_Three[0].equals("X") && Cashier_Three[1].equals("X") && Cashier_Three[2].equals("X")
                && Cashier_Three[3].equals("X") && Cashier_Three[4].equals("X")) {
            System.out.println("Cashier Three is empty(There is no customers in this queue)");
        }

    }



    // The following addCustomerToQueue method is using to add customers to the cashier queues
    private static void addCustomerToCashierQueue() {
        try {
            Scanner addCustomer = new Scanner(System.in);

            //Assigning a boolean type variable called engaged, and it is equal to false
            boolean engaged = false;

            //Now asking User to enter inputs
            System.out.print("Enter customer's first name: ");
            String firstName = addCustomer.nextLine();

            System.out.print("Enter customer's second name: ");
            String secondName = addCustomer.nextLine();

            System.out.print("Enter Customer's ID number : ");
            int id_num = addCustomer.nextInt();

            System.out.print("Amount of Pizzas required: ");
            int pizzaAmount = addCustomer.nextInt();

            addCustomer.nextLine();


            Customer newCustomer = new Customer(firstName, secondName, id_num, pizzaAmount);

            //When the user is adding customers to queues it will replace as 'O' for that I used for loop with if else statements

            for (int x = 0; x < 2; x++) {
                if (Cashier_One[x].equals("X")) {
                    Cashier_One[x] = "O";
                    currentQueue[0].addCustomerToCashierQueue(newCustomer);
                    engaged = true;
                    break;

                } else if (Cashier_Two[x].equals("X")) {
                    Cashier_Two[x] = "O";
                    currentQueue[1].addCustomerToCashierQueue(newCustomer);
                    engaged = true;

                    break;

                } else if (Cashier_Three[x].equals("X")) {
                    Cashier_Three[x] = "O";
                    currentQueue[2].addCustomerToCashierQueue(newCustomer);
                    engaged = true;
                    break;
                }
            }
            if (!engaged) {
                for (int y = 2; y < 3; y++) {
                    if (Cashier_Two[y].equals("X")) {
                        Cashier_Two[y] = "O";
                        currentQueue[1].addCustomerToCashierQueue(newCustomer);
                        engaged = true;

                        break;
                    }
                    if (Cashier_Three[y].equals("X")) {
                        Cashier_Three[y] = "O";
                        currentQueue[2].addCustomerToCashierQueue(newCustomer);
                        engaged = true;

                        break;
                    }
                }


                if (!engaged) {
                    if (Cashier_Three[3].equals("X")) {
                        Cashier_Three[3] = "O";
                        currentQueue[2].addCustomerToCashierQueue(newCustomer);
                    } else if (Cashier_Three[4].equals("X")) {
                        Cashier_Three[4] = "0";
                        currentQueue[2].addCustomerToCashierQueue(newCustomer);
                    } else {
                        System.out.println("All queues are Full");
                        customerWaitingList.enqueue(newCustomer);
                        System.out.println("Customer was added to the waiting list.");
                    }
                }
            }
        }catch (Exception e){
            System.out.println();
            System.out.println("Enter a valid option.");
        }
    }



    // The following removeACustomer method is using for remove a customer from given cashier queue and given position by user
    private static void removeCustomerFromCashierQueue() {
        Scanner input = new Scanner(System.in);

        do {
            try {
                System.out.print("Choose a cashier queue (1,2 or 3) :  ");
                // Define an integer type variable called cashierQueueNUM purpose of this variable to get cashier number
                int cashierQueueNUM = input.nextInt();

                System.out.print("Enter the customer queue position : ");
                //Define an integer type variable called position purpose of this variable to get position of customer in the given cashier number
                int position = input.nextInt();

                cashierQueueNUM -= 1;
                position -= 1;

                //Define a string type variable called selectedQueue
                //And checking user given queue number by using if elseif conditions
                String[] selectedQueue;
                if (cashierQueueNUM == 0) {
                    selectedQueue = Cashier_One;
                }
                else if (cashierQueueNUM == 1) {
                    selectedQueue = Cashier_Two;
                }
                else if (cashierQueueNUM == 2) {
                    selectedQueue = Cashier_Three;
                }
                else {
                    System.out.println("ERROR! Enter valid cashier queue number and position  ");
                    break;
                }

                //From this if statement it is checking the user given position is valid or not
                if (position < 0 || position >= selectedQueue.length) {
                    System.out.println("ERROR! Enter valid cashier queue number and position ");
                    break;
                }

                //From this if statement checking is the cashier queue is empty it will display an error message
                if (selectedQueue[position].equals("X")) {
                    System.out.println("\nNO Customers!!. That position is EMPTY!!\n");
                    System.out.println();
                }
                else {
                    System.out.println("\n__Customer Removed From the given Cashier Queue Number and the given Position__\n");
                    selectedQueue[position] = "X";
                    deployCustomerSlots(cashierQueueNUM, position);
                    currentQueue[cashierQueueNUM].removeCustomerFromCashierQueue(position);


                }
                break;
            }
            catch (InputMismatchException e) {
                System.out.println("Error!! Enter an valid Integer Input");
                input.nextLine();
            }
            catch (Exception e) {
                System.out.println("ERROR!! Try Again! Thank you!");
            }
        }
        while (true);
    }



    // The Following replaceQueueSlots method is using to shift customers after remove a customers from the queue
    private static void deployCustomerSlots(int queueLine, int queuePosition) {
        if (queueLine == 0) {
            for (int p = queuePosition; p < Cashier_One.length - 1; p++) {
                Cashier_One[p] = Cashier_One[p + 1];
            }
            Cashier_One[Cashier_One.length - 1] = "X";
        }
        else if (queueLine == 1) {
            for (int q = queuePosition; q < Cashier_Two.length - 1; q++) {
                Cashier_Two[q] = Cashier_Two[q + 1];
            }
            Cashier_Two[Cashier_Two.length - 1] = "X";
        }
        else if (queueLine == 2) {
            for (int r = queuePosition; r < Cashier_Three.length - 1; r++) {
                Cashier_Three[r] = Cashier_Three[r + 1];
            }
            Cashier_Three[Cashier_Three.length - 1] = "X";
        }
    }



    // The following recognizeOrganizedCustomers method is using to organize customer's names into alphabetic order.
    private static void reOrganizedCustomers() {
        // Creating an Array List to put customer Names
        ArrayList<String> givenNames = new ArrayList<>();

        // Going through of every cashier queues to identify the position of each customer names.
        for (CustomerSnackQueue Position : currentQueue) {

            Customer[] customersDetails = Position.getCustomers();
            for (Customer customer : customersDetails) {
                if (customer != null) {
                    // creating a construct called fullName
                    String fullName = customer.getCustomerFirstName() + " " + customer.getCustomerSecondName();
                    //Adding the fullName to the above array list by given names from the user.
                    givenNames.add(fullName);
                }
            }
        }
        // getting the total number of names
        int n = givenNames.size();

        //In this Section use the bubble sort method to sor out the customer names
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (givenNames.get(j).compareTo(givenNames.get(j + 1)) > 0) {
                    // Swapping the Customer names
                    String temp = givenNames.get(j);
                    givenNames.set(j, givenNames.get(j + 1));
                    givenNames.set(j + 1, temp);
                }
            }
        }
        System.out.println("Re-Organized Customer Name list: ");
        for (String name : givenNames) {
            System.out.println(" **  " + name);
        }
    }


    //The following pizzaCount method is used display remaining pizza stock
    public static void pizzaStock() {
        System.out.println("Last Remaining Pizza Stock is "+ pizza_Count);
    }



    // The following removeAServedCustomer method is used to remove a customer from a user given queue
    private static void removeAServedCustomer() {
        // Create a scanner called remove to get user input
        Scanner remove = new Scanner(System.in);

        // First from this section it is going to check cashier queues are empty or not
        if (Cashier_One[0].equals("X") && Cashier_Two[0].equals("X") && Cashier_Three[0].equals("X")) {
            System.out.println("All cashier Queues are Empty!! No Customers!!");

        }

        else if (pizza_Count <=0) {
            System.out.println("_Not enough stock fulfill the customer order_");
        }

        else {

            // Creating an infinite loop to identify the user Input
            while (true) {
                try {
                    System.out.print("Input a cashier queue number (1,2,3): ");
                    int CashierNumber = remove.nextInt();// Reading the above user input
                    remove.nextLine();//the last newline character in the input should be consumed.

                    //Checking user entered cashier queue number is valid or not
                    if (CashierNumber<1 || CashierNumber>3) {
                        System.out.println("Enter an valid cashier Queue Number (1,2,3)");
                        System.out.println();
                        continue;// If the user input is not valid again re-looping to get valid input from the user.
                    }

                    CashierNumber -= 1;

                    // Now build up the statements according to the cashier queue number that user entered.
                    String[] chosenCashierQueue;
                    if (CashierNumber == 0) {
                        chosenCashierQueue = Cashier_One;
                    } else if (CashierNumber == 1) {
                        chosenCashierQueue = Cashier_Two;
                    } else if (CashierNumber == 2) {
                        chosenCashierQueue = Cashier_Three;
                    } else {
                        System.out.println("ERROR! Input valid cashier Queue : ");
                        System.out.println();
                        break;
                    }

                    // Checking if the given cashier queue is empty or not
                    if (chosenCashierQueue[0].equals("X")) {
                        System.out.println("No customers in the given cashier queue " + (CashierNumber+1));
                        System.out.println();
                        break;
                    }
                    else if (chosenCashierQueue[0].equals("O")) {
                        // Processing the customer order from the selected cashier queue.
                        chosenCashierQueue[0] = "X";//Adjusting the chosen cashier slot as available.
                        int pizza_BUY = currentQueue[CashierNumber].removeCustomerFromCashierQueue(0);

                        // Updating Pizza Stock and Cashier queue income after the customer order.
                        pizza_Count -= pizza_BUY;
                        cashierQueuesIncome[CashierNumber] += pizza_BUY * 1350;

                        // New pizza stock will be displayed to the user
                        System.out.println("New Pizza stock: " + pizza_Count);
                        System.out.println();

                        // Calling method here tho shift the next customer in the slot after the purchase.
                        deployCustomerSlots(CashierNumber, 0);

                        // Checking if there are customer in the waiting list in this program
                        if (customerWaitingList.queueEmpty()) {
                            System.out.println("NO Customers! (waiting list)");
                            System.out.println();
                        } else {

                            //Shifting waiting list customer into the current queue
                            Customer customer1 = customerWaitingList.dequeue();
                            if(CashierNumber==0){
                                currentQueue[0].addCustomerToCashierQueue(customer1);}
                            if(CashierNumber==1){
                                currentQueue[1].addCustomerToCashierQueue(customer1);}
                            if(CashierNumber==2){
                                currentQueue[2].addCustomerToCashierQueue(customer1);}

                            // Adjusting the last postion as occupied according to the user given cashier queue.
                            chosenCashierQueue[chosenCashierQueue.length-1] = "O";}

                        // In this if condition is checking if the pizza stock is low or not if it is low it will display a warning message to the user.
                        if (pizza_Count <= 20) {
                            System.out.println();
                            System.out.println("========WARNING========");
                            System.out.println("______RISKY STOCK______");
                            System.out.println("Pizza stock is too low");
                        }
                        break;// Exit the infinite loop
                    }
                }
                catch (InputMismatchException e) {
                    // // If user input an invalid input beside integer value it asks renter the valid input from the user.
                    System.out.println("Input a valid cashier queue (1,2,3) : ");
                    System.out.println();
                    remove.nextLine();// Consuming the invalid inputs getting by user
                }
            }
        }
    }



    // The following addPizzaStock method is using to add new pizzas into the stock
    private static void addPizzaStock() {
        try {
            // Create a Scanner object called newPIZZA to get user input.
            Scanner newPIZZA = new Scanner(System.in);

            //Asking amount of pizza that user want to add
            System.out.print("Amount of Pizzas do you want to add?: ");
            int pizzaAmount = newPIZZA.nextInt();//Reading the above user's input
            newPIZZA.nextLine();//the last newline character in the input should be consumed.

            //Checking the user input amount compatible with total of 100 pizzas.
            if (pizzaAmount<100 &&(pizzaAmount + pizza_Count)<=100) {
                // If that above statement true, adding above amount into pizza stock
                pizza_Count+=pizzaAmount;
                System.out.println("This amount of " + pizzaAmount + " added to the Pizza Stock..");
                System.out.println();
            }
            else {
                // If the user given amount exceeding the maximum pizza stock displaying an error message to the user.
                System.out.println();
                System.out.println("This Amount of " + pizzaAmount + " Pizzas can not add ");
                System.out.println("Sorry Maximum pizza stock is 100 can not add more.");
            }
        }
        catch (InputMismatchException e) {
            // If user input an invalid input beside integer value it will show an error message.
            System.out.println("Error! Invalid Input! Try again with an integer value");
        }
        // For the line spacing
        System.out.println();
    }



    // The following cashierQueuesIncome method use to calculate the income from each cashier queue
    // One Pizza = 1350/=
    private static void cashierQueuesIncome() {
        //To check the income from each cashier using for loop it will go through every cashier queue
        for (int i = 0; i < currentQueue.length; i++) {
            // Displaying the income of the current handling queue
            System.out.println("This Cashier Queue  " + (i+1) + " income : " + cashierQueuesIncome[i]);
        }
        // For the line spacing
        System.out.println();
    }



    // The following storeDatatoTextFile method is used to store all the data in a text file (Customer_Info.txt)
    private static void storeDatatoTextFile() {
        try {
            //Create a text document called Customer_Info.txt to write all data
            FileWriter fileStoring = new FileWriter("Customer_Info.txt");

            //Going through every cashier queues one by one
            for (int i = 0; i< currentQueue.length; i++) {
                //In the text file write a title to the currently handling cashier queue
                fileStoring.write("Customer details in this cashier " + (i+1) + " queue:\n");

                // Obtain the Customer objects array from the active Cashier Queue.
                Customer[] customersDetails = currentQueue[i].getCustomers();

                // Going through every customer in the currently handling cashier queue
                for (Customer customer : customersDetails) {
                    if (customer != null) {
                        //Writing all the Customer Information in the Customer_info.txt file.
                        fileStoring.write("   " + (i+1) + " " + customer.getInfo() + "\n");
                    }
                }
                //from this section After each customer's information in the cashier queue, type a newline.
                fileStoring.write("\n");
            }
            // Writing the remaining data(Pizza stock, Income from each cashier one by on)
            fileStoring.write("\nPizza stock: " + pizza_Count);
            fileStoring.write("\n\nIncome from each cashier queue :\n");
            for (int i = 0; i < currentQueue.length; i++) {
                fileStoring.write("Cashier queue " + (i+1) + " - " + cashierQueuesIncome[i] + "\n");
            }
            // Closing file writng after finish writing in the text file.
            fileStoring.close();
            System.out.println("Data stored in the file.\n");
        }
        catch (IOException e) {
            // Showing an error message to the user if there is an issue with writing in the text file.
            System.out.println("Error! Data is not storing Try Again\n");
        }
    }



    //The Following loadDatatoTextFile method is used to load all the data that saved in the stored file
    private static void loadDatatoTextFile() {

        try {

            String[] Cashier_One = {"X", "X"};
            String[] Cashier_Two = {"X", "X", "X"};
            String[] Cashier_Three = {"X", "X", "X", "X", "X"};

            // Creating an array of objects called CustomerFoodQueue
            CustomerSnackQueue[] queueCustomer = new CustomerSnackQueue[3];
            queueCustomer[0] = new CustomerSnackQueue(2);
            queueCustomer[1] = new CustomerSnackQueue(3);
            queueCustomer[2] = new CustomerSnackQueue(5);

            //In this section reading all the customer details into this file
            File file = new File("Customer_Info.txt");
            Scanner information = new Scanner(file);
            boolean employed = false;

            while (information.hasNextLine()) {
                String path = information.nextLine();
                path = path.trim();
                String[] input = path.split("  ");

                if (input.length == 5) {
                    //Getting Customer information from the user input
                    int queuePositionNumber = Integer.parseInt(input[0]) - 1;
                    String first_Name = input[1];
                    String second_Name = input[2];
                    int pizzaAmount = Integer.parseInt(input[4]);

                    //Creating a new object called Customer with above Customer information
                    Customer customerDetails = new Customer(first_Name, second_Name, pizzaAmount);

                    //Adding the customer to empty cashier queues
                    queueCustomer[queuePositionNumber].addCustomerToCashierQueue(customerDetails);

                    //Assignning customers to empty queues by using for loop and if elseif statements
                    for (int g = 0; g < 2; g++) {
                        if (Cashier_One[g].equals("X")) {
                            Cashier_One[g] = "O";
                            queueCustomer[0].addCustomerToCashierQueue(customerDetails);
                            employed = true;


                            break;

                        } else if (Cashier_Two[g].equals("X")) {
                            Cashier_Two[g] = "O";
                            queueCustomer[1].addCustomerToCashierQueue(customerDetails);
                            employed = true;

                            break;

                        } else if (Cashier_Three[g].equals("X")) {
                            Cashier_Three[g] = "O";
                            queueCustomer[2].addCustomerToCashierQueue(customerDetails);
                            employed = true;
                            break;


                        }


                    }
                    //Adding customers to the next available cashier if there is no cashier available.
                    if (!employed) {
                        for (int i = 2; i < 3; i++) {
                            if (Cashier_Two[i].equals("X")) {
                                Cashier_Two[i] = "O";
                                queueCustomer[1].addCustomerToCashierQueue(customerDetails);
                                employed = true;
                                break;
                            }
                            if (Cashier_Three[i].equals("X")) {
                                Cashier_Three[i] = "O";
                                queueCustomer[2].addCustomerToCashierQueue(customerDetails);
                                employed = true;
                                break;
                            }
                        }

                        //Adding customers to the waiting list if all cashier queues are full.
                        if (!employed) {
                            if (Cashier_Three[3].equals("X")) {
                                Cashier_Three[3] = "O";
                                queueCustomer[2].addCustomerToCashierQueue(customerDetails);
                            } else if (Cashier_Three[4].equals("X")) {
                                Cashier_Three[4] = "0";
                                queueCustomer[2].addCustomerToCashierQueue(customerDetails);
                            } else {
                                System.out.println("All CASHIER QUEUES are full");
                                System.out.println("All CustomerDetails transferred into waiting list queue.");
                            }
                        }
                    }
                }
                if (input.length == 4) {
                    cashierQueuesIncome[Integer.parseInt(input[1])-1] = Integer.parseInt(input[3]);
                }
                if (input.length == 3) {
                    pizza_Count = Integer.parseInt(input[2]);
                }
            }
            information.close();
            System.out.println();
            System.out.println("Data loaded into the file\n");
        }
        catch (IOException e) {
            System.out.println("Error! Data is not Loading into the file Try Again\n");
        }
    }


}
// Reference List
// https://www.javatpoint.com/bubble-sort-in-java
// https://www.w3schools.com/java/java_files_create.asp
// https://www.w3schools.com/java/java_try_catch.asp
// https://www.w3schools.com/java/java_for_loop.asp
// https://www.w3schools.com/java/java_switch.asp