public class WaitingCustomerQueue{
    private Customer[] customersDetails;
    private int front;
    private int rear;
    private int size;

    public WaitingCustomerQueue(int capacity) {
        customersDetails = new Customer[capacity];
        front = front-1;
        rear = rear-1;
        size = 0;
    }


    public boolean queueFull() {
        return size == customersDetails.length;
    }

    public boolean queueEmpty() {
        return size == 0;
    }

    public void enqueue(Customer customer) {
        if (queueFull()) {
            System.out.println("Can not add customers into the queue, Waiting queue is full with customers Sorry Try AGAIN!.");
            return;
        }

        if (queueEmpty()) {
            front = 0;
        }

        rear = (rear + 1) % customersDetails.length;
        customersDetails[rear] = customer;
        size=size+1;

        System.out.println(customer.getCustomerFirstName() + "__This Customer added to the Waiting Customer Queue__");
    }

    public Customer dequeue() {
        if (queueEmpty()) {
            System.out.println("Cannot Remove given Customer, The Waiting List EMPTY!");
            return null;
        }

        Customer customersDetail = customersDetails[front];
        customersDetails[front] = null;

        if (front == rear) {
            front = front-1;
            rear = rear-1;
        } else {
            front = (front + 1) % customersDetails.length;
        }

        size = size-1;
        return customersDetail;
    }

    public int getFront() {

        return front;
    }
    public int getRear() {

        return rear;
    }
    public Customer[] getCustomersDetails() {

        return customersDetails;
    }
    public int getSize() {

        return size;
    }

}

// Reference list
// https://www.programiz.com/dsa/circular-queue
// https://prepinsta.com/java-program/circular-queue/

