public class Customer {

    private String customerFirstName;
    private String customerSecondName;
    private int PizzaAmount;
    private int id_num;

    public Customer(String customerFirstName, String customerSecondName,int id_num, int PizzaAmount) {
        this.customerFirstName = customerFirstName;
        this.customerSecondName = customerSecondName;
        this.PizzaAmount = PizzaAmount;
        this.id_num = id_num;
    }
    public Customer(String customerFirstName, String customerSecondName, int PizzaAmount) {
        this.customerFirstName = customerFirstName;
        this.customerSecondName = customerSecondName;
        this.PizzaAmount = PizzaAmount;
    }

    //The following method is used to get the customer's first name

    public String getCustomerFirstName() {
        return customerFirstName;
    }

    //The following method is used to get the customer's Second name
    public String getCustomerSecondName() {
        return customerSecondName;
    }

    //The following method is getting amount of pizzas that requires to the given customer order
    public int getPizzaAmount() {
        return PizzaAmount;
    }

    public String getInfo() {
        return customerFirstName + " " + customerSecondName + " - " + PizzaAmount;
    }

}