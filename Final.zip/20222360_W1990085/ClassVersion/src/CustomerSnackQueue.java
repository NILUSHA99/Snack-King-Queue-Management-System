public class CustomerSnackQueue {

    private Customer[] customers;
    private int quantity;
    private int incomeQueue;
    private final int pizzaPrice = 650;

    public CustomerSnackQueue(int quantity) {
        this.customers = new Customer[quantity];
        this.quantity = quantity;
        this.incomeQueue = 0;
    }

    public void addCustomerToCashierQueue(Customer customer) {
        for (int i=0; i<customers.length; i++) {
            if (customers[i] == null) {
                customers[i] = customer;
                System.out.println("\n" + customer.getCustomerFirstName() + " added to the relavant cashier queue");
                break;
            }
        }

    }

    public int removeCustomerFromCashierQueue(int index) {
        System.out.println("\n This Served customer: '" + customers[index].getCustomerFirstName() + "' removed from user given cashier queue ");
        int PizzaAmount = customers[index].getPizzaAmount();
        customers[index] = null;
        shiftCustomerSpots(index);
        return PizzaAmount;
    }

    public void shiftCustomerSpots(int index) {
        for (int i=index; i<customers.length; i++) {
            if (i+1 == customers.length) {
                customers[i] = null;
                break;
            }
            customers[i] = customers[i+1];
        }

    }

    public Customer[] getCustomers() {
        return customers;
    }

}